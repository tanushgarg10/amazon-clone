# Amazon-Clone

## A clone of the Amazon website for practicing web development skills.

## Technologies used :
   1. HTML
   2. CSS
   3. JAVASCRIPT


## Project Image
### Home Page
![Screenshot 2023-12-19 222803](https://github.com/akashdeep023/Amazon-Clone/assets/126412088/76cbf588-128f-4362-a344-8f021f4bcef6)
![Screenshot 2023-12-19 220750](https://github.com/akashdeep023/Amazon-Clone/assets/126412088/38c77534-3ff6-423a-a917-d479cd18f5af)
![Screenshot 2023-12-19 220838](https://github.com/akashdeep023/Amazon-Clone/assets/126412088/7bf8bc88-a26b-4797-9095-9d4691afccb7)
![Screenshot 2023-12-19 220936](https://github.com/akashdeep023/Amazon-Clone/assets/126412088/eeee40a0-a694-4e3f-aa3d-899592c0e40f)
![Screenshot 2023-12-19 221028](https://github.com/akashdeep023/Amazon-Clone/assets/126412088/f2412acc-f41d-40d7-a6d9-e1d403cfedef)

### Footer Page
![Screenshot 2023-12-19 221108](https://github.com/akashdeep023/Amazon-Clone/assets/126412088/6da7a1d7-500b-483d-b0e4-4816c7b1a4b6)
![Screenshot 2023-12-19 221136](https://github.com/akashdeep023/Amazon-Clone/assets/126412088/2ee9323f-d01a-43af-b522-45afa1be6b06)


### Thanks for visit... 😊😊😊
